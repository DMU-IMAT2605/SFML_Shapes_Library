var searchData=
[
  ['transformshape_35',['TransformShape',['../class_shapes.html#a8341d7c1a78a2b5717593bf26771e60c',1,'Shapes']]],
  ['triangle_36',['Triangle',['../class_triangle.html',1,'Triangle'],['../class_triangle.html#ad2f77d55f2b31ddd4b447f304c104aa7',1,'Triangle::Triangle()']]]
];
