var searchData=
[
  ['transformshape_70',['TransformShape',['../class_shapes.html#a8341d7c1a78a2b5717593bf26771e60c',1,'Shapes']]],
  ['triangle_71',['Triangle',['../class_triangle.html#ad2f77d55f2b31ddd4b447f304c104aa7',1,'Triangle']]]
];
