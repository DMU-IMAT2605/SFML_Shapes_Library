var searchData=
[
  ['scaleshape_63',['ScaleShape',['../class_shapes.html#a43529b2ff21439294ae3494fde159c58',1,'Shapes']]],
  ['setangles_64',['SetAngles',['../class_arc.html#ad0a5f972e6491961dfd3f3fb4334b1ea',1,'Arc']]],
  ['setcentre_65',['SetCentre',['../class_arc.html#a6c2ec0ecc844ea342a199a207321c66b',1,'Arc']]],
  ['setradius_66',['SetRadius',['../class_arc.html#aca1172af32f38b04e25ddda5b1e6e401',1,'Arc']]],
  ['setrotating_67',['SetRotating',['../class_shapes.html#a25347e9eab290a34670fb74f436a7e0b',1,'Shapes']]],
  ['shapes_68',['Shapes',['../class_shapes.html#ab4e8c3c78bab3c2a9be3402896e30626',1,'Shapes']]],
  ['square_69',['Square',['../class_square.html#a374189fbb655cdfbf266ce9ed75b7d5a',1,'Square']]]
];
