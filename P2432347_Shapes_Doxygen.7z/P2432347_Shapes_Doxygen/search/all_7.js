var searchData=
[
  ['rainbowcolour_24',['RainbowColour',['../class_shapes.html#ab14b581a121ee9c0a0970cbd49cc2e50',1,'Shapes']]],
  ['rectangle_25',['Rectangle',['../class_rectangle.html',1,'Rectangle'],['../class_rectangle.html#a8a933e0ebd9e80ce91e61ffe87fd577e',1,'Rectangle::Rectangle()']]],
  ['rotateshape_26',['RotateShape',['../class_shapes.html#a798da977a36e69b3ccda6b9fc9a7d205',1,'Shapes']]]
];
