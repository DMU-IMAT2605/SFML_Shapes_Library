var searchData=
[
  ['getcentre_57',['GetCentre',['../class_arc.html#ae1f6fb9b7dd294d82c036dbb69ca3974',1,'Arc']]],
  ['getradius_58',['GetRadius',['../class_arc.html#a931229755fa13f83d61a374c6626c97f',1,'Arc']]],
  ['getrotating_59',['GetRotating',['../class_shapes.html#a0502333dc7555d2382ee1ed0c7331751',1,'Shapes']]]
];
