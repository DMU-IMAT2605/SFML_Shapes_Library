var searchData=
[
  ['triangle_45',['Triangle',['../class_triangle.html',1,'']]]
];
