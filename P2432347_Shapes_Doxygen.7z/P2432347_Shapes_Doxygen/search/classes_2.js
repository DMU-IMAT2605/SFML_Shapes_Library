var searchData=
[
  ['dot_39',['Dot',['../class_dot.html',1,'']]]
];
